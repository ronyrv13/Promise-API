// function user(name){
//     this.name = name;
// }
// user.prototype.SayHi = function (){
//     alert(this.name)
// }
// let user = new user("Rony");
// user.SayHi();

class User{
    constructor(name){
        this.name = name;
    }
    SayHi (){
        alert(this.name)
    }
}

var user = new User ('Hii Rony');
user.SayHi();  