
var http = require('http');
var fs = require('fs');
//2.

var Connection = require('tedious').Connection;  
var config = {  
    userName: 'figmd',  
    password: '2hpu9erS',  
    server: '192.168.105.58',
    database:'APA_FIGMDHQIManagementDemo',
    options: 
    {
        database:'APA_FIGMDHQIManagementDemo'
    }
};  

var connection = new Connection(config);  
connection.on('connect', function(err) {  
    
    console.log("Connected");  
   
});  

var Request = require('tedious').Request;  
var TYPES = require('tedious').TYPES;  

function executeStatement() 
{  
    var result = "";
    var DbObject=null; 
    request = new Request("select top 10 * from FIGUser ", function(err) {  
    if (err) {  
        console.log(err);}  
    });  
     
    request.on('row', function(columns) { 
        DbObject=columns; 
        columns.forEach(function(column) {  
          if (column.value === null) 
          {  
            console.log('NULL');  
          } else 
          {  
              
            result+= column.value + " ";  
          }  
        });  

       
        console.log(result);  
        // result ="";  
       
    });  

    request.on('done', function(rowCount, more) {  
    console.log(rowCount + ' rows returned');  
    });  
    connection.execSql(request);  
   // return DbObject;
}  
var server = http.createServer(function (req, resp) {
    //3.
    if (req.url === "/create") {
        fs.readFile("MyPage.html", function (error, pgResp) {
            if (error) {
                resp.writeHead(404);
                resp.write('Contents you are looking are Not Found');
            } else {

                resp.writeHead(200, { 'Content-Type': 'text/html' });
                // resp.write(columns.column.value);
               resp.write(pgResp);
              var columns =  executeStatement();
              var Gridhtml="";  
            //   columns.forEach(function(column){

            //     Gridhtml += "<tr><td>'"+column.value+"'</td></tr>"

            //   });
              //console.log(columns);
             
            
            document.getElementById("Nodetable").innerHTML = Gridhtml;
            }
             
            resp.end();
        });
    } else {
        //4.
        resp.writeHead(200, { 'Content-Type': 'text/html' });
        resp.write('<h1>Product Manaager</h1><br /><br />To create product please enter: ' + req.url);
        resp.end();
    }
});
//5.
server.listen(5050);
 
console.log('Server Started listening on 5050');