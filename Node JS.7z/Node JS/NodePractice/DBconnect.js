var express = require('express');
var fs = require('fs');
var app = express();
    var Connection = require('tedious').Connection;  
    var config = {  
        userName: 'figmd',  
        password: '2hpu9erS',  
        server: '192.168.105.58',
        database:'APA_FIGMDHQIManagementDemo',
        options: 
        {
            database:'APA_FIGMDHQIManagementDemo'
        }
    };  

    var connection = new Connection(config);  
    connection.on('connect', function(err) {  
        
        console.log("Connected");  
       
    });  

    var Request = require('tedious').Request;  
    var TYPES = require('tedious').TYPES;  
    app.get('/listUsers', function (req, res) {
 
        request = new Request("SELECT QuestionUid,Question,Description,SrNo from MasterQuestion", function(err) {  
        if (err) {  
            console.log(err);}  
        });  

        fs.readFile('Grid.html', function(err, data) {
            res.writeHead(200, {'Content-Type': 'text/html'});
            res.write(data);
            return res.end();
          });
     
        request.on('done', function(rowCount, more) {  
        console.log(rowCount + ' rows returned');  
        });  
        connection.execSql(request);  
     

});
var server = app.listen(1420, '127.0.0.1');
console.log('Server running at 127.0.0.1:1420');