var express = require('express');
var app = express();
var fs = require("fs");

app.get('/listUsers', function (req, res) {
   fs.readFile( __dirname + "/" + "users.json", 'utf8', function (err, data) {
       console.log( data );
      
       res.end( data );
   });
})

var server = app.listen(1420, '127.0.0.1');
console.log('Server running at 127.0.0.1:1420');