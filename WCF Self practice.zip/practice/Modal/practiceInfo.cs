﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Runtime.Serialization;


namespace Modal
{
    [DataContract]
   public  class practiceInfo
    {
        [DataMember]
        public string serialNo { get;  set; }

        [DataMember]
        public string practiceUid { get; set; }

        [DataMember]
        public string ListName { get; set; }

        [DataMember]
        public string inactive { get; set; }
        
    }
}
