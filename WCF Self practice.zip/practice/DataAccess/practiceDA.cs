﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modal;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;


namespace DataAccess
{
    public class praciceDA
    {
        public string getPracticeData(practiceInfo pInfo)
        {
            DataTable dTable = new DataTable();

            try
            {
              
                string connectionString = System.Configuration.ConfigurationManager.AppSettings["FIGMDHQIManagement"];
                using (SqlConnection _conn = new SqlConnection(connectionString))
                {

                    SqlCommand cmd = new SqlCommand("_practiceDetails01", _conn);
                    cmd.CommandText = "_practiceDetails01";
                    cmd.CommandType = CommandType.StoredProcedure;
                
                    using (SqlDataAdapter dataAdapter = new SqlDataAdapter(cmd))
                    {
                        dataAdapter.Fill(dTable);
                    }
                }

            }
            catch (SqlException ex)
            {
                Console.WriteLine("SQL Error: " + ex.Message);
            }
            catch (Exception e)
            {
                Console.WriteLine("Error: " + e.Message);
            }

            List<practiceInfo> bag = new List<practiceInfo>();
            practiceInfo Ginfo = new practiceInfo();
                if (dTable.Rows.Count>0)
                {
                    for (int i = 0; i < dTable.Rows.Count; i++)
                    {
                        Ginfo.serialNo = dTable.Rows[i]["rid"].ToString() ;
                        Ginfo.practiceUid = dTable.Rows[i]["PracticeUid"].ToString();
                        Ginfo.ListName = dTable.Rows[i]["ListName"].ToString();
                        Ginfo.inactive = dTable.Rows[i]["Inactive"].ToString();
                        bag.Add(Ginfo);
                    }
                }
                return bag.ToString();

        }


    }
}
