﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Modal;
using DataAccess;

namespace Business
{
   public class practiceBusiness
    {
       public  string GetGridList(practiceInfo pInfo)
       {
           praciceDA daObject = new praciceDA();
           return daObject.getPracticeData(pInfo);
       }

    }
}
